Cartoonify by Somyajit Chakraborty

Dependencies:
1. OpenCV cv2
2. Torch/ Torchvision (Pytorch)
3. numpy
4. scipy
5. PIL
6. matplotlib
7. Skimage (Scikit-Learn Image)
8. argparse


Instructions:
1. Keep all the images in the same directory as the Notebook(.ipynb) file.
2. Read the Latex made pdf first, for smooth reading.
3. For checking each image while testing remeber to change the image number in 3 different parts: 'personi.jpg', 'bg_removedi.jpg', 'cartooni.jpg' where i=[1,10] range.